//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-udXJt8aB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analytics",
			"/channels",
			"/passed",
			"/settings",
			"/token/$address"
		],
		preloads: [
			"/assets/index-CSrWozfc.js",
			"/assets/clsx-uf39P5xP.js",
			"/assets/link-DwxnxruX.js",
			"/assets/dist-2ZwpL6t5.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CSrWozfc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-bImk8iaO.js", "/assets/token-card-C3Az8npZ.js"]
	},
	"/analytics": {
		filePath: "/workspace/src/routes/analytics.tsx",
		children: void 0,
		preloads: ["/assets/analytics-DqlysOEK.js", "/assets/BarChart-_0hcifIi.js"]
	},
	"/channels": {
		filePath: "/workspace/src/routes/channels.tsx",
		children: void 0,
		preloads: [
			"/assets/channels-BXZtdpM1.js",
			"/assets/switch-BHoGqMGD.js",
			"/assets/links-HG_rvwve.js"
		]
	},
	"/passed": {
		filePath: "/workspace/src/routes/passed.tsx",
		children: void 0,
		preloads: [
			"/assets/passed-CGrpPHdD.js",
			"/assets/external-link-Czoclonc.js",
			"/assets/links-HG_rvwve.js",
			"/assets/token-card-C3Az8npZ.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-Bsss36p5.js", "/assets/switch-BHoGqMGD.js"]
	},
	"/token/$address": {
		filePath: "/workspace/src/routes/token.$address.tsx",
		children: void 0,
		preloads: [
			"/assets/token._address-BtlXpEPL.js",
			"/assets/external-link-Czoclonc.js",
			"/assets/BarChart-_0hcifIi.js",
			"/assets/links-HG_rvwve.js",
			"/assets/status-badge-WpoSGHK5.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
