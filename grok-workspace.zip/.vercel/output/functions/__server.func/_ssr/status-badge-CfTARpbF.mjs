import { f as formatScore } from "./scoring-B5PSSDgX.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { s as cn } from "./router-__-WlQ8r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-badge-CfTARpbF.js
var import_jsx_runtime = require_jsx_runtime();
function ScoreMark({ value, passed, size = 56 }) {
	const stroke = 3.5;
	const r = 12.5;
	const c = 2 * Math.PI * r;
	const pct = Math.min(100, Math.max(0, value ?? 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative inline-flex items-center justify-center",
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 32 32",
			className: "size-full -rotate-90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r,
				fill: "none",
				stroke: "var(--color-surface-2)",
				strokeWidth: stroke
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r,
				fill: "none",
				stroke: passed ? "var(--color-pass)" : value == null ? "var(--color-muted)" : pct >= 72 ? "var(--color-warn)" : "var(--color-fail)",
				strokeWidth: stroke,
				strokeDasharray: `${pct / 100 * c} ${c}`,
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("absolute font-mono text-sm tabular", passed ? "text-pass" : "text-fg"),
			children: formatScore(value)
		})]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "bg-primary text-primary-foreground",
		mute: "bg-surface-2 text-muted",
		pass: "bg-pass/15 text-pass",
		fail: "bg-fail/15 text-fail",
		warn: "bg-warn/15 text-warn",
		info: "bg-info/15 text-info",
		outline: "border border-border text-muted"
	} },
	defaultVariants: { variant: "mute" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var MAP = {
	extracted: {
		label: "Extracted",
		variant: "mute"
	},
	enriching: {
		label: "Enriching",
		variant: "info"
	},
	analyzing: {
		label: "Analyzing",
		variant: "warn"
	},
	scored: {
		label: "Scored",
		variant: "info"
	},
	passed: {
		label: "Passed",
		variant: "pass"
	},
	rejected: {
		label: "Rejected",
		variant: "fail"
	}
};
function StatusBadge({ status }) {
	const item = MAP[status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: item.variant,
		children: item.label
	});
}
//#endregion
export { ScoreMark as n, StatusBadge as r, Badge as t };
