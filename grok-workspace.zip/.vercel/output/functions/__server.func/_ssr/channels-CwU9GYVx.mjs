import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAlpha, i as Button, r as Input } from "./router-__-WlQ8r.mjs";
import { t as telegramChannelUrl } from "./links-BFKHKanq.mjs";
import { n as Switch, t as Label } from "./switch-CvF3ISI8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/channels-CwU9GYVx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChannelsPage() {
	const channels = useAlpha((s) => s.channels);
	const tokens = useAlpha((s) => s.tokens);
	const addChannel = useAlpha((s) => s.addChannel);
	const toggleChannel = useAlpha((s) => s.toggleChannel);
	const removeChannel = useAlpha((s) => s.removeChannel);
	const [handle, setHandle] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("channel");
	function onAdd(e) {
		e.preventDefault();
		addChannel({
			handle,
			title,
			kind
		});
		setHandle("");
		setTitle("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-muted uppercase",
					children: "Sources"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight sm:text-3xl",
					children: "Channels"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted",
					children: "The desk listens to this roster. Live Solana launches are attributed across enabled desks the way a userbot would fan them in. Toggle a source off to stop routing new mints through it."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onAdd,
				className: "grid gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:grid-cols-[1fr_1fr_auto_auto] sm:items-end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "handle",
							children: "Telegram handle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "handle",
							value: handle,
							onChange: (e) => setHandle(e.target.value),
							placeholder: "sol_alpha_desk",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "title",
							children: "Display name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "title",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: "Sol Alpha Desk"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "kind",
							children: "Type"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "kind",
							value: kind,
							onChange: (e) => setKind(e.target.value),
							className: "h-11 w-full rounded-lg border border-input bg-surface px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "channel",
								children: "Channel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "bot",
								children: "Bot"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "min-h-11",
						children: "Add source"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: channels.map((ch) => {
					const fromHere = tokens.filter((t) => t.sourceChannelId === ch.id);
					const passed = fromHere.filter((t) => t.status === "passed").length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium",
										children: ch.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-surface-2 px-2 py-0.5 text-xs uppercase tracking-wide text-muted",
										children: ch.kind
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: telegramChannelUrl(ch.handle),
									target: "_blank",
									rel: "noreferrer",
									className: "font-mono text-xs text-muted underline-offset-4 hover:underline",
									children: ["t.me/", ch.handle]
								}),
								ch.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-subtle",
									children: ch.note
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4 font-mono text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular",
									children: [fromHere.length, " in"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular text-pass",
									children: [passed, " pass"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: ch.enabled,
									onCheckedChange: () => toggleChannel(ch.id),
									"aria-label": `Toggle ${ch.title}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => removeChannel(ch.id),
									children: "Remove"
								})
							]
						})]
					}, ch.id);
				})
			})
		]
	});
}
//#endregion
export { ChannelsPage as component };
