import { i as QUOTE_MINTS, m as isSolanaMint, s as emptyMetrics } from "./scoring-B5PSSDgX.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-LlcBhqBp.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var RPCS = ["https://solana-rpc.publicnode.com", "https://api.mainnet-beta.solana.com"];
async function fetchJson(url, init, timeoutMs = 8e3) {
	const res = await fetch(url, {
		...init,
		signal: AbortSignal.timeout(timeoutMs),
		headers: {
			accept: "application/json",
			...init?.headers ?? {}
		}
	});
	if (!res.ok) throw new Error(`${url} ${res.status}`);
	return await res.json();
}
function ageMin(createdAt) {
	if (createdAt == null) return null;
	const ts = typeof createdAt === "number" ? createdAt : Date.parse(createdAt);
	if (!Number.isFinite(ts)) return null;
	return Math.max(0, (Date.now() - ts) / 6e4);
}
function num(v) {
	if (v == null || v === "") return null;
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : null;
}
function tokenAddr(id) {
	if (!id) return null;
	return id.startsWith("solana_") ? id.slice(7) : id;
}
function fromGecko(res) {
	const tokens = /* @__PURE__ */ new Map();
	for (const row of res.included ?? []) if (row.type === "token") tokens.set(row.id, row);
	const out = [];
	for (const pool of res.data ?? []) {
		const baseId = pool.relationships?.base_token?.data?.id;
		const quoteId = pool.relationships?.quote_token?.data?.id;
		const base = tokens.get(baseId ?? "");
		const quote = tokens.get(quoteId ?? "");
		let mint = base?.attributes.address ?? tokenAddr(baseId);
		let name = base?.attributes.name ?? pool.attributes.name;
		let symbol = base?.attributes.symbol ?? pool.attributes.name.split("/")[0] ?? "???";
		const quoteMint = quote?.attributes.address ?? tokenAddr(quoteId);
		if (mint && QUOTE_MINTS.has(mint) && quoteMint && !QUOTE_MINTS.has(quoteMint)) {
			mint = quoteMint;
			name = quote?.attributes.name ?? name;
			symbol = quote?.attributes.symbol ?? symbol;
		}
		if (!mint || !isSolanaMint(mint)) continue;
		out.push({
			address: mint,
			name: name || symbol || "Unknown",
			symbol: (symbol || "???").slice(0, 12),
			dexId: pool.relationships?.dex?.data?.id ?? null,
			pairAddress: pool.attributes.address,
			imageUrl: base?.attributes.image_url ?? null,
			liquidityUsd: num(pool.attributes.reserve_in_usd),
			mcapUsd: num(pool.attributes.market_cap_usd) ?? num(pool.attributes.fdv_usd),
			volume24h: num(pool.attributes.volume_usd?.h24),
			pairAgeMin: ageMin(pool.attributes.pool_created_at),
			createdAt: pool.attributes.pool_created_at
		});
	}
	return out;
}
async function gecko(path) {
	return fetchJson(`https://api.geckoterminal.com/api/v2/networks/solana/${path}?include=base_token,quote_token,dex&page=1`, { headers: { accept: "application/json;version=20230302" } });
}
var listLaunchTape_createServerFn_handler = createServerRpc({
	id: "a6cb405f7241a0b70e40b0d707fe81c0931c5dc6ccadc617e3e7e6e00b6136c1",
	name: "listLaunchTape",
	filename: "src/lib/alpha/api.ts"
}, (opts) => listLaunchTape.__executeServer(opts));
var listLaunchTape = createServerFn({ method: "GET" }).handler(listLaunchTape_createServerFn_handler, async () => {
	const [fresh, trend] = await Promise.allSettled([gecko("new_pools"), gecko("trending_pools")]);
	const rows = [];
	if (fresh.status === "fulfilled") rows.push(...fromGecko(fresh.value));
	if (trend.status === "fulfilled") rows.push(...fromGecko(trend.value));
	const seen = /* @__PURE__ */ new Set();
	const unique = [];
	for (const row of rows) {
		if (seen.has(row.address)) continue;
		seen.add(row.address);
		unique.push(row);
	}
	return {
		launches: unique,
		fetchedAt: Date.now(),
		source: unique.length ? "geckoterminal" : "empty"
	};
});
function pickPair(address, pairs) {
	const sol = (pairs ?? []).filter((p) => p.chainId === "solana");
	const ranked = (sol.length ? sol : pairs ?? []).slice().sort((a, b) => {
		const al = a.liquidity?.usd ?? 0;
		return (b.liquidity?.usd ?? 0) - al;
	});
	return ranked.find((p) => p.baseToken.address === address || p.quoteToken.address === address) ?? ranked[0] ?? null;
}
function metricsFromPair(address, pair) {
	const m = emptyMetrics();
	if (!pair) return m;
	const baseIsMint = pair.baseToken.address === address;
	m.priceUsd = num(pair.priceUsd);
	m.liquidityUsd = pair.liquidity?.usd ?? null;
	m.volume24h = pair.volume?.h24 ?? null;
	m.volume1h = pair.volume?.h1 ?? null;
	m.volume5m = pair.volume?.m5 ?? null;
	m.mcapUsd = pair.marketCap ?? pair.fdv ?? null;
	m.fdvUsd = pair.fdv ?? null;
	m.buys24h = pair.txns?.h24?.buys ?? null;
	m.sells24h = pair.txns?.h24?.sells ?? null;
	m.buys1h = pair.txns?.h1?.buys ?? null;
	m.sells1h = pair.txns?.h1?.sells ?? null;
	m.pairAgeMin = ageMin(pair.pairCreatedAt);
	m.dexId = pair.dexId ?? null;
	m.pairAddress = pair.pairAddress ?? null;
	m.pairUrl = pair.url ?? null;
	m.priceChange24h = pair.priceChange?.h24 ?? null;
	if (!baseIsMint && pair.quoteToken.address === address) m.dexId = pair.dexId;
	return m;
}
async function rpc(method, params) {
	let lastErr;
	for (const url of RPCS) try {
		const json = await fetchJson(url, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				jsonrpc: "2.0",
				id: 1,
				method,
				params
			})
		}, 7e3);
		if (json.error) throw new Error(json.error.message ?? "rpc error");
		return json.result?.value;
	} catch (err) {
		lastErr = err;
	}
	throw lastErr instanceof Error ? lastErr : /* @__PURE__ */ new Error("rpc failed");
}
async function readMint(address) {
	const facts = {
		mintAuthority: void 0,
		freezeAuthority: void 0,
		decimals: null,
		supply: null,
		tokenProgram: null,
		topHolders: [],
		holderCoveragePct: null,
		queriedAt: null
	};
	try {
		const value = await rpc("getAccountInfo", [address, { encoding: "jsonParsed" }]);
		if (!value) return facts;
		const info = value.data?.parsed?.info;
		facts.tokenProgram = value.owner ?? null;
		facts.mintAuthority = info?.mintAuthority ?? null;
		facts.freezeAuthority = info?.freezeAuthority ?? null;
		facts.decimals = info?.decimals ?? null;
		facts.supply = info?.supply ?? null;
		facts.queriedAt = Date.now();
	} catch {
		return facts;
	}
	try {
		const largest = await rpc("getTokenLargestAccounts", [address]);
		const supply = facts.supply ? Number(facts.supply) : 0;
		const decimals = facts.decimals ?? 0;
		const rows = [];
		let covered = 0;
		for (const row of largest ?? []) {
			const ui = row.uiAmount ?? (row.amount ? Number(row.amount) / 10 ** decimals : 0);
			const raw = row.amount ? Number(row.amount) : ui * 10 ** decimals;
			const pct = supply > 0 ? raw / supply * 100 : 0;
			covered += pct;
			rows.push({
				address: row.address ?? "",
				pct,
				uiAmount: ui
			});
		}
		facts.topHolders = rows;
		facts.holderCoveragePct = covered;
	} catch {}
	return facts;
}
var inspectMint_createServerFn_handler = createServerRpc({
	id: "39ad0ea222870b5192e950942c075ffc4bd15de0808c6bf193aa84424ce5d91a",
	name: "inspectMint",
	filename: "src/lib/alpha/api.ts"
}, (opts) => inspectMint.__executeServer(opts));
var inspectMint = createServerFn({ method: "POST" }).validator(object({ address: string().min(32).max(44) })).handler(inspectMint_createServerFn_handler, async ({ data }) => {
	const address = data.address.trim();
	if (!isSolanaMint(address)) throw new Error("Not a Solana mint");
	const [dex, onchain] = await Promise.allSettled([fetchJson(`https://api.dexscreener.com/latest/dex/tokens/${address}`), readMint(address)]);
	const pair = pickPair(address, dex.status === "fulfilled" ? dex.value.pairs : []);
	const market = metricsFromPair(address, pair);
	const base = pair?.baseToken.address === address ? pair.baseToken : pair?.quoteToken.address === address ? pair.quoteToken : pair?.baseToken;
	return {
		address,
		name: base?.name ?? shortUnknown(address),
		symbol: (base?.symbol ?? "???").slice(0, 14),
		market,
		onchain: onchain.status === "fulfilled" ? onchain.value : {
			mintAuthority: void 0,
			freezeAuthority: void 0,
			decimals: null,
			supply: null,
			tokenProgram: null,
			topHolders: [],
			holderCoveragePct: null,
			queriedAt: null
		},
		imageUrl: null
	};
});
function shortUnknown(address) {
	return `token ${address.slice(0, 4)}`;
}
//#endregion
export { inspectMint_createServerFn_handler, listLaunchTape_createServerFn_handler };
