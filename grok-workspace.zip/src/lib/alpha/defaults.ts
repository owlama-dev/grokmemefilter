import type { Channel, Weights } from "./types";

export const APP_NAME = "AlphaFilter";
export const APP_TAGLINE = "Second-layer filter for Solana telegram calls";

export const DEFAULT_THRESHOLD = 72;

export const DEFAULT_WEIGHTS: Weights = {
  deployer: 15,
  freshWallets: 12,
  concentration: 15,
  bundles: 15,
  lpLock: 12,
  authorities: 12,
  liquidity: 10,
  organic: 9,
};

export const WEIGHT_META: Record<
  keyof Weights,
  { label: string; blurb: string }
> = {
  deployer: {
    label: "Deployer trail",
    blurb: "Whether the mint still answers to a wallet, and how that reads on a fresh launch.",
  },
  freshWallets: {
    label: "Fresh wallets",
    blurb: "Early tape crowded with brand-new buyers usually means funded insiders.",
  },
  concentration: {
    label: "Holder concentration",
    blurb: "Top wallets after peeling off the LP / bonding curve.",
  },
  bundles: {
    label: "Bundle / same-block",
    blurb: "Launch clustering — snipers and bundled supply in the opening tape.",
  },
  lpLock: {
    label: "LP quality",
    blurb: "Depth versus float, and whether the curve/LP looks protocol-owned.",
  },
  authorities: {
    label: "Mint & freeze",
    blurb: "Authorities revoked on-chain. Both live is a hard risk.",
  },
  liquidity: {
    label: "Liquidity & size",
    blurb: "USD depth, volume quality, and whether the book can actually be traded.",
  },
  organic: {
    label: "Organic flow",
    blurb: "Unique buyers versus churn, buy/sell balance, wash-like spikes.",
  },
};

export const DEFAULT_CHANNELS: Channel[] = [
  {
    id: "alpha-desk",
    handle: "sol_alpha_desk",
    title: "Sol Alpha Desk",
    kind: "channel",
    enabled: true,
    note: "Curated calls. Usually slower, slightly cleaner tape.",
  },
  {
    id: "degen-wire",
    handle: "degen_wire",
    title: "Degen Wire",
    kind: "channel",
    enabled: true,
    note: "High volume. Expect more bonding-curve noise.",
  },
  {
    id: "smart-flow",
    handle: "smart_flow_sol",
    title: "Smart Flow",
    kind: "channel",
    enabled: true,
    note: "Wallet-follow style alerts, often late but more sized-in.",
  },
  {
    id: "lp-sentry",
    handle: "lp_sentry_bot",
    title: "LP Sentry",
    kind: "bot",
    enabled: true,
    note: "New-pair bot. Fires on pool creation, no opinion.",
  },
  {
    id: "bundle-tape",
    handle: "bundle_tape",
    title: "Bundle Tape",
    kind: "channel",
    enabled: false,
    note: "Noisy sniper channel. Off by default.",
  },
];

export const QUOTE_MINTS = new Set([
  "So11111111111111111111111111111111111111112",
  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
  "USD1ttGY1N17NEEHLmELoaybftRJYQPBm4FBqct1uk5",
  "27G8MtK7VtTcCHkpASjSDdkWWYfoqT6ggEuKid3Npj6Q",
]);

export const SOLANA_CA_RE = /\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g;
